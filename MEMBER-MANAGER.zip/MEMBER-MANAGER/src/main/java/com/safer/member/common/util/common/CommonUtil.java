package com.safer.member.common.util.common;

public class CommonUtil {

}
