package com.safer.member.module.login.blogic;

import com.safer.member.module.base.interfac.Blogic;

/**
 * 登陆逻辑处理类
 * @author renqing
 * 2017-2-3 下午03:22:12
 */
public class LoginBlogic implements Blogic<Integer, Integer> {

	/**
	 * 执行登陆逻辑
	 * @param i 用户对象
	 * @return
	 */
	@Override
	public Integer execute(Integer i) {
		// TODO Auto-generated method stub
		return 1;
	}


}
