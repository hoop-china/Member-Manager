package com.safer.member.module.base.interfac;

/**
 * blogic 处理业务接口
 * @author renqing
 * 2017-2-3 下午03:18:04
 */
public interface Blogic<IN, OUT> {

	/**
	 * 执行业务逻辑
	 * @param i  入参
	 * @return   出参
	 */
	OUT execute(IN i);
}
