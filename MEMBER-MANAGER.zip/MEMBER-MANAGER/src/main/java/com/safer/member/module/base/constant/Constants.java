package com.safer.member.module.base.constant;

/**
 * 常量类
 * @author renqing
 * 2017-2-4 上午10:57:04
 */
public class Constants {

	private Constants(){}

	/**
	 * 普通常量
	 */
	public static final String test1 = "123";

	/**
	 * 枚举类型
	 * @author renqing
	 * 2017-2-4 上午10:58:40
	 */
    public enum DISPATCHPROCESSTYPE{

        VODCREATE("0"), // VOD新建
        PHYCHANNELUPDATE("39"),//物理频道更新
        VODMODIFYTRAN("91");

        private String value;

        private DISPATCHPROCESSTYPE(String value) {

            this.value = value;
        }

        public String toString() {
            return this.value;
        }
    }
}
