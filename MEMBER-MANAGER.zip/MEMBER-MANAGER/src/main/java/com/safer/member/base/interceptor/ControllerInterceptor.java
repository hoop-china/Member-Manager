package com.safer.member.base.interceptor;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.safer.member.module.base.constant.Constants;

/**
 * Controller 拦截器
 * @author renqing
 * 2017-2-4 下午01:53:28
 */
public class ControllerInterceptor extends HandlerInterceptorAdapter {

    /**
     * controller计时器记录阈值(2000毫秒)
     */
    private String controllerConsumeMillisecondThreshold = "2000";


    /**
     * handler执行前
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws HttpSessionRequiredException,IOException {

        // SESSION为空时，抛出SESSION异常
        if (null == request.getSession()) {

            throw new HttpSessionRequiredException("no Session");
        } else {

            String uri = request.getRequestURI();

            // 请求的CONTROLLER非登录或退出时
            if (!(uri.contains("/login")||uri.contains("/logout")||uri.contains("queue/pgeaQuery"))) {

                // 用户信息为空时，抛出SESSION异常
                if (request.getSession().getAttribute("sysUser") == null) {

                    throw new HttpSessionRequiredException("no Session");
                }

                // 如果不是上传请求
                if (!(request instanceof DefaultMultipartHttpServletRequest)){

                    // 获取上一次请求地址
                    String comeUrl = request.getHeader("REFERER");

                    // 当上次请求地址为空时（地址栏直接输入URL），进行首页重定向
                    if (StringUtils.isEmpty(comeUrl)) {
                        response.sendRedirect("/CMS/login");
                    }
                }
            }
        }

        /*if (log.isInfoEnabled()) {

            SysUser sysUser = (SysUser) request.getSession().getAttribute("sysUser");

            StringBuffer sb = new StringBuffer();
            sb.append("***");
            sb.append(" Controller preHandle");
            sb.append(" url:");
            sb.append(request.getRequestURI());
            sb.append(" user:");
            sb.append(sysUser == null ? null : sysUser.getUserName());
            sb.append(" role:");
            sb.append(sysUser == null ? null : sysUser.getRoleName());
            sb.append(" ***");

            log.info(sb.toString());
        }*/

        long startMilliSecond = System.currentTimeMillis();
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(Constants.test1);

        // controller 开始执行前日期时间
        request.setAttribute("controllerStartDateTime", sdf.format(date) );

        // controller 开始执行前毫秒数
        request.setAttribute("controllerStartMillis", startMilliSecond );

        return true;
    }

    /**
     * handler执行后
     */
    @Override
    public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler,
            ModelAndView modelAndView){

        /*if (log.isInfoEnabled()) {

            SysUser sysUser = (SysUser) request.getSession().getAttribute("sysUser");

            StringBuffer sb = new StringBuffer();
            sb.append("***");
            sb.append(" Controller postHandle");
            sb.append(" url:");
            sb.append(modelAndView == null ? null : modelAndView.getViewName());
            sb.append(" user:");
            sb.append(sysUser == null ? null : sysUser.getUserName());
            sb.append(" role:");
            sb.append(sysUser == null ? null : sysUser.getRoleName());
            sb.append(" ***");

            log.info(sb.toString());
        }
*/
        // controller 开始执行前日期时间
        String startDateTime = (String) request.getAttribute("controllerStartDateTime");

        // controller 执行结束后毫秒数
        long endMilliSecond = System.currentTimeMillis();

        // controller 开始执行前毫秒数
        long startMilliSecond = (Long) request.getAttribute("controllerStartMillis");

        // controller 消耗毫秒数
        long consumeMilliSecond = endMilliSecond - startMilliSecond;

        // 记录controller耗费时间（2000毫秒以上）
       /* if (consumeMilliSecond > Long.parseLong(controllerConsumeMillisecondThreshold)) {

            controllerTimeConsumeMapper.addControllerTimeConsumeRecord(handler.getClass().getName(), request.getRequestURI(), request.getMethod(), startDateTime, Long.toString(consumeMilliSecond));

        }*/

    }
}
