package com.safer.member.module.base.constant;

/**
 * 全局变量
 * @author renqing
 * 2017-2-4 上午11:10:43
 */
public class Global {

}
